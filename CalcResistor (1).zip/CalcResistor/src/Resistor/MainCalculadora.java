package Resistor;


public class MainCalculadora {
    

    public static void main(String[] args) {
       FramePrincipal Frame = new FramePrincipal("Calculadora Gráfica de Resistor");
       
      
    }
    
}
